
package com.order.UIController;

 

import java.util.*;

 

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;

import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestMethod;

 

import com.order.exception.CustomerNotFoundException;

import com.order.model.Customers;

import com.order.services.CustomerService;

 

import jakarta.validation.Valid;

 

@Controller

@RequestMapping("/api/ui/customer")

public class CustomerUIController {


	@Autowired

	CustomerService customerService;


	@RequestMapping(method = RequestMethod.GET , value="/all")

	public String getAllCustomer(Model model) {

		List<Customers> customers=customerService.getAllCustomer();

		model.addAttribute("customers", customers);

		return "allCustomers";

	}


	@RequestMapping(method = RequestMethod.GET , value="/delete/{id}")

	public String getCustomerAddForm(@PathVariable("id") int id) throws CustomerNotFoundException {

		System.out.println(id);

		customerService.deleteCustomer(id);

		return "redirect:/api/ui/customer/all";

	}



	@RequestMapping(method = RequestMethod.GET , value="/add")

	public String getCustomerAddForm(Model model) {

		Customers customer = new Customers();

		customer.setCustomer_id(111);

		model.addAttribute("newCustomer", customer);

		return "addCustomer";

	}


	@RequestMapping(method = RequestMethod.POST , value="/add")

	public String addNewCustomer(@Valid @ModelAttribute("newCustomer")  Customers  customer) {


		customerService.createCustomers(customer);

		return "redirect:/api/ui/customer/all";

	}


//	@RequestMapping(method = RequestMethod.GET , value="/view/{id}")

//	public String getCustomerById(Model model , @PathVariable("id") int id) throws CustomerNotFoundException   {

//		Optional<Customers> customer=customerService.getCustomerById(id);

//		model.addAttribute("customer", customer);

//		return "oneCustomer";

//	}


	@GetMapping("/view/{id}")

 

    public String getCustomerById(Model model, @PathVariable("id") int id) throws CustomerNotFoundException {

 

        Customers customer = customerService.getCustomersById(id);

 

        model.addAttribute("customer", customer);

 

        return "oneCustomer";

 

	}


//	@RequestMapping(value = "/updateCustomer", method = RequestMethod.POST)   

//	 public String updateCustomer(@ModelAttribute("customer") Customers customer)

//	 {         customerService.save(customer);    

//	    return "redirect:/customers";     }

//	

//	@RequestMapping(value = "/updateCustomer/{id}", method = RequestMethod.GET)

//	public String updateCustomerForm(@PathVariable int id, Model model) throws CustomerNotFoundException

//	 {     

//		Customers customer = customerService.getCustomersById(id);

//		customer.setCustomer_id(customer.getCustomer_id());

//		

//	    model.addAttribute("customer", customer);  

//	    return "updateCustomer"; }


	@GetMapping("/update/{Id}")

    public String getUpdateCustomerForm(@PathVariable("Id") int Id, Model model) throws CustomerNotFoundException {

        // Retrieve the department data for the form

        Customers customer = customerService.getCustomersById(Id);

        // Populate the model with the department data

        model.addAttribute("updatedCustomer", customer);

        return "updateCustomer"; // Return the view template

    }


	  // Handle form submission

		 @PostMapping("/update/{Id}")

		    public String updateCustomer(


		        @ModelAttribute("updatedCustomer") Customers updatedCustomer,

		        Model model

		    ) {

		        try {

		            // You should validate and sanitize the input here if needed

		            // Then, update the department

		        	customerService.updateByCustomerId(updatedCustomer);

		            return "redirect:/api/ui/customer/all"; // Redirect to the department list page

		        } catch (CustomerNotFoundException e) {

		            // Handle the exception, e.g., show an error message

		            return "error"; // Create an error template

		        }

		    }

//		

		 // delete to be implemented

//		 @RequestMapping(method = RequestMethod.GET , value="/delete/{id}")

//

//			public String getShippersAddForm(@PathVariable("id") int id) throws ShippersNotFoundException  {

//

//				System.out.println(id);

//

//				shippersService.deleteShipper(id);

//

//				return "redirect:/api/ui/shippers/all";

//

//			

//	 

//

	}



 