
package com.order.model;

import jakarta.persistence.Entity;
import jakarta.persistence.*;

@Entity
@Table(name = "INVENTORY")

public class Inventory {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "INVENTORY_ID")
    private int inventory_id;

	@ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "PRODUCT_ID") 
    private Products products;

    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "STORE_ID") 
    private Stores stores;
    
    
    @Column(name = "PRODUCT_INVENTORY")
    private int product_inventory;

	public int getInventory_id() {
		return inventory_id;
	}

	public void setInventory_id(int inventory_id) {
		this.inventory_id = inventory_id;
	}

	

	public Products getProducts() {
		return products;
	}

	public void setProducts(Products products) {
		this.products = products;
	}

	public int getProduct_inventory() {
		return product_inventory;
	}

	public void setProduct_inventory(int product_inventory) {
		this.product_inventory = product_inventory;
	}
    
    
	   public Stores getStores() {
			return stores;
		}

		public void setStores(Stores stores) {
			this.stores = stores;
		}

    
    
}
