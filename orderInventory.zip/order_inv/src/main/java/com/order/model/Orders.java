package com.order.model;
import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnore;


import java.util.List;

@Entity
@Table(name = "ORDERS")
public class Orders { 

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
   
    @Column(name = "ORDER_ID")
    private int orderId;
   
  
    @Column(name = "ORDER_TMS",nullable = false)
    private String orderTimestamp;
   
  
    @Column(name = "ORDER_STATUS",nullable = false)
    private String orderStatus;
   
    @JsonIgnore
    @OneToMany(mappedBy = "orders", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<OrderItems> orderItems;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "CUSTOMER_ID")
    private Customers customers;


    @JsonIgnore
    @ManyToOne
    @JoinColumn(name = "STORE_ID")
    private Stores stores;


	public int getOrderId() {
       	return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;

	}

	

	public String getOrderTimestamp() {
		return orderTimestamp;
	}

	public void setOrderTimestamp(String orderTimestamp) {
		this.orderTimestamp = orderTimestamp;
	}

	public String getOrderStatus() {
		return orderStatus;

	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;

	}


	public List<OrderItems> getOrderItems() {
		return orderItems;
	}


	public void setOrderItems(List<OrderItems> orderItems) {
		this.orderItems = orderItems;
	}


	public Customers getCustomers() {
		return customers;
	}


	public void setCustomers(Customers customers) {
		this.customers = customers;
	}


	public Stores getStores() {
		return stores;
	}


	public void setStores(Stores stores) {
		this.stores = stores;
	}

	public void setOrderId(Orders orderId2) {
		// TODO Auto-generated method stub
		
	}

}

 

 