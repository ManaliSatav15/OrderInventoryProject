
package com.order.model;

 

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;

import jakarta.persistence.Column;

import jakarta.persistence.Entity;

import jakarta.persistence.FetchType;

import jakarta.persistence.GeneratedValue;

import jakarta.persistence.GenerationType;

import jakarta.persistence.Id;

import jakarta.persistence.OneToMany;

import jakarta.persistence.Table;

import jakarta.validation.constraints.NotBlank;

import jakarta.validation.constraints.Size;

 

@Entity

@Table(name="CUSTOMERS")

public class Customers {

 

	@Id

	@GeneratedValue(strategy=GenerationType.AUTO)

 

	@Column(name="CUSTOMER_ID")

	private int customer_id;

 

	

	public List<Shipments> getShipments() {

		return shipments;

	}

 

 

 

	public void setShipments(List<Shipments> shipments) {

		this.shipments = shipments;

	}

 

 

 

	public List<Orders> getOrders() {

		return orders;

	}

 

 

 

	public void setOrders(List<Orders> orders) {

		this.orders = orders;

	}

 

 

   

	@Column(name="EMAIL_ADDRESS" ,nullable=false,unique=true)

	@NotBlank(message = "Email must not be blank")

	private String email_address;

 

	@Column(name="FULL_NAME", nullable=false)

	@Size(max=30, min=5, message="The customer full name has to be bwtween 5-30 characters")

	private String full_name;

 

	@OneToMany(mappedBy = "customers", fetch = FetchType.LAZY, cascade = CascadeType.ALL)

	@JsonIgnore

	private List<Shipments> shipments;

 

	@OneToMany(mappedBy = "customers", fetch = FetchType.LAZY, cascade = CascadeType.ALL)

	@JsonIgnore

    private List<Orders> orders;

 

	public int getCustomer_id() {

 

		return customer_id;

 

	}

 

 

 

	public void setCustomer_id(int customer_id) {

 

		this.customer_id = customer_id;

 

	}

 

 

 

	public String getEmail_address() {

 

		return email_address;

 

	}

 

 

 

	public void setEmail_address(String email_address) {

 

		this.email_address = email_address;

 

	}

 

 

 

	public String getFull_name() {

 

		return full_name;

 

	}

 

 

 

	public void setFull_name(String full_name) {

 

		this.full_name = full_name;

 

	}

 

	

 

	

 

	

 

}