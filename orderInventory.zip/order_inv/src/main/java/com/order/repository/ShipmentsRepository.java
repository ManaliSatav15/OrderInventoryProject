package com.order.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.order.model.Shipments;

public interface ShipmentsRepository extends JpaRepository<Shipments,Integer>{

	
//	@Query(select s.count(s.shipment_id) from shipments s where s.STORE_ID in (select store_id from Stores st where storeName = 'online'));

	@Query("select sp.shipment_id from Shipments sp")
	public List<Integer> findAllShipmentId();


}