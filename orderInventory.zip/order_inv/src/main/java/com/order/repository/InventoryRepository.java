package com.order.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.order.dto.InventoryProductCustomerStore;
import com.order.dto.InventoryProductStoreShipmentStatusSum;
import com.order.dto.InventoryShipment;
import com.order.dto.ShipmentStatusSoldProducts;
import com.order.model.Inventory;

public interface InventoryRepository extends JpaRepository<Inventory,Integer>{

	
	/*
	 * @Query annotation represents a custom SQL query that retrieves specific data from the "Order" and "OrderItem" tables based on a specific order ID. 
	 */
	@Query("select new com.order.dto.InventoryProductCustomerStore(oi.products, o.customers, o.stores) "
			+"from Orders o join OrderItems oi "
			+"on o.orderId = oi.orders.orderId "
			+"where o.orderId = ?1")
	public InventoryProductCustomerStore findProductCustomerStoreByOrderId(@Param("id") int orderId);
	
	/*
	 * @Query annotation represents a custom SQL query that retrieves specific data from the "OrderItem" and "Order" tables based on a specific order ID.
	 */
	@Query("SELECT new com.order.dto.InventoryProductStoreShipmentStatusSum(oi.products, o.stores, oi.shipments.shipment_status, SUM(oi.unitPrice * oi.quantity) AS total) " +
	        "FROM OrderItems oi " +
	        "JOIN oi.orders o " +
	        "WHERE oi.orders.orderId = ?1 " +
	        "GROUP BY oi.products")
	public List<InventoryProductStoreShipmentStatusSum> findInventoryDetailsByOrderId(@Param("orderId") int orderId);

/*
 * @Query annotation represents a custom SQL query that retrieves specific data from the "OrderItem" and "Order" tables based on a specific store ID.
 */
	
	//select p , o.orderStatus from Products p inner join 
	@Query("SELECT oi.products, o.orderStatus FROM OrderItems oi inner JOIN Orders o on o.orderId = oi.orders.orderId WHERE o.stores.storeId = :storeId")
	public List<Object[]> findProductOrderStatusByStoreId(@Param("storeId") int storeId);
	
	/*
	 * @Query annotation represents a custom SQL query that retrieves specific data from the "Shipment" and "Inventory" tables based on a specific shipment ID.
	 */
	@Query("SELECT new com.order.dto.InventoryShipment(sp, i) FROM Shipments sp JOIN Inventory i on sp.stores.storeId = i.stores.storeId WHERE sp.shipment_id = ?1")
	public InventoryShipment findInventoryShipmentById(@Param("shipmentId") int shipmentId);
	
	/*
	 * @Query annotation represents a custom SQL query that retrieves specific data related to shipped and delivered products.
	 */
	@Query("select new com.order.dto.ShipmentStatusSoldProducts('DELIVERED' as status, count(o.products)) from Shipments s join OrderItems o on s.shipment_id = o.shipments.shipment_id where s.shipment_status = 'DELIVERED'")
	public ShipmentStatusSoldProducts findSoldProductsByShipmentStatus();
	
}
