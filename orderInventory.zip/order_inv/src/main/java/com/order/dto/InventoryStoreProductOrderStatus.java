package com.order.dto;

import java.util.List;

import com.order.model.Stores;

public class InventoryStoreProductOrderStatus {
	private Stores store;
	private List<Object[]> object;
	/**
	 * @param store
	 * @param object
	 */
	public InventoryStoreProductOrderStatus(Stores store, List<Object[]> object) {
		super();
		this.store = store;
		this.object = object;
	}
	/**
	 * Getters and Setters
	 */
	public InventoryStoreProductOrderStatus() {
		super();
	}
	/**
	 * @return the store
	 */
	public Stores getStore() {
		return store;
	}
	/**
	 * @param store the store to set
	 */
	public void setStore(Stores store) {
		this.store = store;
	}
	/**
	 * @return the object
	 */
	public List<Object[]> getObject() {
		return object;
	}
	/**
	 * @param object the object to set
	 */
	public void setObject(List<Object[]> object) {
		this.object = object;
	}
	
}
