package com.order.dto;

import java.util.List;

import com.order.model.Customers;
import com.order.model.Orders;

public class CustomerOrders {
	private Customers customer;
	private List<Orders> order;
	  
	
	
	public CustomerOrders(Customers customer, List<Orders> order) {
	
		this.customer = customer;
		this.order = order;
	}
	
	public Customers getCustomer() {
		return customer;
	}
	/**
	 * @param customer the customer to set
	 */
	public void setCustomer(Customers customer) {
		this.customer = customer;
	}
	/**
	 * @return the order
	 */
	public List<Orders> getOrder() {
		return order;
	}
	/**
	 * @param order the order to set
	 */
	public void setOrder(List<Orders> order) {
		this.order = order;
	}
	
	
}
