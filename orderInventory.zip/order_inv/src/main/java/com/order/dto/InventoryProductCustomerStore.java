package com.order.dto;

import com.order.model.Customers;
import com.order.model.Products;
import com.order.model.Stores;
import com.order.model.Customers;
import com.order.model.Products;
import com.order.model.Stores;

public class InventoryProductCustomerStore {
	private Products product;
	private Customers customer;
	private Stores store;
	/**
	 * @param product
	 * @param customer
	 * @param store
	 */
	public InventoryProductCustomerStore(Products product, Customers customer, Stores store) {
		super();
		this.product = product;
		this.customer = customer;
		this.store = store;
	}
	/**
	 * Getters and Setters
	 */
	public InventoryProductCustomerStore() {
		super();
	}
	/**
	 * @return the product
	 */
	public Products getProduct() {
		return product;
	}
	/**
	 * @param product the product to set
	 */
	public void setProduct(Products product) {
		this.product = product;
	}
	/**
	 * @return the customer
	 */
	public Customers getCustomer() {
		return customer;
	}
	/**
	 * @param customer the customer to set
	 */
	public void setCustomer(Customers customer) {
		this.customer = customer;
	}
	/**
	 * @return the store
	 */
	public Stores getStore() {
		return store;
	}
	/**
	 * @param store the store to set
	 */
	public void setStore(Stores store) {
		this.store = store;
	}
}
