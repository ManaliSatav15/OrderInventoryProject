package com.order.services;

import java.util.*;

import com.order.dto.OrderStoreDTO;
import com.order.exception.OrderNotFoundException;

import com.order.model.Orders;


public interface OrderService {

	public Orders getOrderById(int orderId) throws OrderNotFoundException;
	public List<Orders> getAllOrders();
	public Orders createOrders(Orders orders);
	public Orders updateOrders(Orders orders) throws OrderNotFoundException;
	public String deleteOrders(int orderId) throws OrderNotFoundException;

	public List<OrderStoreDTO> getOrderAndStores(int storeId);
	
	
	public int getcountOfStatusByOrderStatus(String orderStatus);
	//Orders updateOrd(Orders orders) throws OrderNotFoundException;
	
	//public List<OrderStoreDTO> findByStoreId(int storeId);
	
}
