package com.order.services;
import java.util.*;

import com.order.exception.ShipmentNotFoundException;
import com.order.model.Shipments;
public interface ShipmentService {
	Shipments getshipmentById(int shipmentId) throws ShipmentNotFoundException;
	List<Shipments> getAllShipment();
	void createShipments(Shipments shipments);
	Shipments updateShipment(Shipments shipments) throws ShipmentNotFoundException;
	void deleteShipments(int orderId) throws ShipmentNotFoundException;

	
}

