package com.order.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Service;

import com.order.dto.InventoryProductCustomerStore;
import com.order.dto.InventoryProductStoreShipmentStatusSum;
import com.order.dto.InventoryShipment;
import com.order.dto.InventoryStoreProductOrderStatus;
import com.order.dto.ShipmentStatusSoldProducts;
import com.order.exception.InventoryNotFoundException;
import com.order.model.Inventory;
import com.order.model.Stores;
import com.order.repository.InventoryRepository;
import com.order.repository.ShipmentsRepository;
import com.order.repository.StoresRepository;

@Service
public class InventoryServiceImpl implements InventoryService{

	@Autowired
	private InventoryRepository inventoryRepository;
	
	
	@Autowired
	private StoresRepository storeRepository;
	
	@Autowired
	private ShipmentsRepository shipmentRepository;
	
	

	@Override
	public List<Inventory> getAllInventory() {
		return inventoryRepository.findAll();
	}

	@Override
	public void createInventory(Inventory inventory) {
		 inventoryRepository.save(inventory);
		
	}

	@Override
	public Inventory updateInventory(Inventory inventory) throws InventoryNotFoundException {
		if(inventoryRepository.findById(inventory.getInventory_id()).isEmpty())
			throw new InventoryNotFoundException("the order with "+inventory.getInventory_id()+"does not extis");
		return inventoryRepository.save(inventory);
		
	}

	@Override
	public void deleteInventory(int inventoryId) throws InventoryNotFoundException {
		if(inventoryRepository.findById(inventoryId).isEmpty())
			throw new InventoryNotFoundException("the order with "+inventoryId+"does not extis");
		 inventoryRepository.delete(inventoryRepository.findById(inventoryId).get());
		
	}



	@Override
	public Inventory getInventoryById(int inventoryId) throws InventoryNotFoundException {
		if(inventoryRepository.findById(inventoryId).isEmpty())
			throw new InventoryNotFoundException("the order with "+inventoryId+"does not extis");
		return inventoryRepository.findById(inventoryId).get();
	}

	
	
	
	@Override
	public InventoryProductCustomerStore getProductCustomerStoreByOrderId(int orderId) {
		String methodName = "getProductCustomerStoreByOrderId()";
     //   logger.info(methodName + "called");
		return inventoryRepository.findProductCustomerStoreByOrderId(orderId);
	}
	
	
	@Override
	public List<InventoryProductStoreShipmentStatusSum> getInventoryDetailsByOrderId(@Param("orderId") int orderId){
		String methodName = "getInventoryDetailsByOrderId()";
       // logger.info(methodName + "called");
		return inventoryRepository.findInventoryDetailsByOrderId(orderId);
	}
	
	
	@Override
	public InventoryStoreProductOrderStatus getProductOrderStatusByStoreId(int storeId) {
		String methodName = "getProductOrderStatusByStoreId()";
       // logger.info(methodName + "called");
		Stores store = storeRepository.findById(storeId).orElse(null);
		List<Object[]> object = inventoryRepository.findProductOrderStatusByStoreId(storeId);
		return new InventoryStoreProductOrderStatus();
	}
	
	
	@Override
	public List<InventoryShipment> getInventoryShipmentById(){
		String methodName = "getInventoryShipmentById()";
     //   logger.info(methodName + "called");
		List<Integer> allId = shipmentRepository.findAllShipmentId();
		List<InventoryShipment> inventoryShipment = new ArrayList<>();
		for(int id : allId) {
			inventoryShipment.add(inventoryRepository.findInventoryShipmentById(id));
		}
		return inventoryShipment;
	}
	
	
	@Override
	public ShipmentStatusSoldProducts getCountOfSoldProductsByShipmentStatus() {
		String methodName = "getCountOfSoldProductsByShipmentStatus()";
       // logger.info(methodName + "called");
		return inventoryRepository.findSoldProductsByShipmentStatus();
	}
	
}
