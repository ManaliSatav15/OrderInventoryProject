package com.order.services;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.domain.Sort;

import com.order.exception.ProductNotFoundException;
import com.order.model.Products;

public interface ProductService {

	List<Products> getProductByName(String productName) throws ProductNotFoundException;
	List<Products> getAllProducts();
	public Products createProducts(Products products);
	Products updateProducts(Products products) throws ProductNotFoundException;
	void deleteProducts(int productId) throws ProductNotFoundException;
	List<Products> findByProductNameContaining(String productName);
	public String deleteProductById(int id);
	public	String updateProduct(Products product);
	List<Products> getProductsByUnitPriceRange(BigDecimal min, BigDecimal max);
	List<Products> getSortedProductsByField(Sort sort);
	
}
