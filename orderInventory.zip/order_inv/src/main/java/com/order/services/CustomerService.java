package com.order.services;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.order.dto.CustomerOrders;
import com.order.dto.CustomerShipment;
import com.order.dto.ShipmentStatusCountCustomer;
import com.order.exception.CustomerNotFoundException;
import com.order.model.Customers;


public interface CustomerService {

	//public Optional<Customers> getCustomerById(int id);
	List<Customers> getAllCustomer();
	public Customers createCustomers(Customers customers);
	public	Customers updateCustomer(Customers customer) throws CustomerNotFoundException;
	public	Customers updateByCustomerId(Customers customer) throws CustomerNotFoundException;
	public String deleteCustomerById(int id);
	Customers getCustomersById(int Id) throws CustomerNotFoundException;
	void save(Customers customer);
	 
	
	
   public List<Customers> getCustomersByEmail(String Email);
    
   List<ShipmentStatusCountCustomer> getOrderCountByStatus(String shipmentStatus);
	
	public CustomerOrders getCustomerOrders(int customerId);

	CustomerShipment getCustomerShipment(int customerId);
	void deleteCustomer(int id) throws CustomerNotFoundException;
	

    

}