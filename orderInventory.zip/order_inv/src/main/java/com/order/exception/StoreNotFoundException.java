package com.order.exception;

public class StoreNotFoundException extends Exception {
	String message;
	public StoreNotFoundException(String message)
	{
		this.message=message;
	}
	public String  getMessage() {
		return this.message;
	}

}
