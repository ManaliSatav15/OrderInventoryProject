package com.order;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderInvApplicationTests {

	//@Test
	void contextLoads() {
	}

}
